# archdi-pkg

This project is part of archdi.<br>
look at archdi project to use it : https://github.com/MatMoul/archdi

If you want request a new features for archdi use issues on this project (https://github.com/MatMoul/archdi-pkg/issues).

Other way is to fork this project, add features and request a pullback.<br>
For testing, you can use:<br>
archdi -t {githubusername} {archdi-pkg branch name}<br>
as exemple :<br>
archdi -t matmoul src
