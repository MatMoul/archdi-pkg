# archdi-pkg CONTRIBUTING

## Contributing :
* Open an issue before work to hard
* Work on the develop branch

 
