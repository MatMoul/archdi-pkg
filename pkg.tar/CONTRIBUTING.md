# archdi-pkg CONTRIBUTING

## Contributing :
* Open an issue before work to hard
* **Work on the develop branch**
* **Use tab for identation**
* **Preserve identation on empty line**
* **Test your changes (archdi -t github-username archdi-pkg-branchname)**

- [ ] I've read these rules before submitting my PR.
