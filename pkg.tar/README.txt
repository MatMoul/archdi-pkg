# archdi-pkg

This project is part of archdi.<br>
look at archdi project to use it : https://github.com/MatMoul/archdi

If you want request new features for archdi use issues on this project (https://github.com/MatMoul/archdi-pkg/issues).

Other way is to fork this project, add features and request a pullback.
For testing, you can use:
archdi -t {githubusername} {archdi-pkg branch name}
as exemple :
archdi -t matmoul src
